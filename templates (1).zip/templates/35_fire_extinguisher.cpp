/*
 * ============================================================================
 * FILE: 35_fire_extinguisher.cpp
 * ============================================================================
 * FIRE EXTINGUISHER MANAGEMENT SYSTEM - Real-world DSA Application
 *
 * EXAM FREQUENCY: Medium. Asset/inventory management systems are commonly
 * asked in DSA practical exams. This tests BST (serial lookup), hash tables
 * (location-based search), queues (inspection scheduling), stacks (maintenance
 * history), and linked lists (building inventory).
 *
 * DATA STRUCTURES USED:
 *   1. Binary Search Tree - Extinguishers sorted by Serial Number
 *      - O(log n) search by serial number
 *      - In-order traversal for inventory listing
 *   2. Hash Table (unordered_map) - Location-based Lookup
 *      - O(1) find all extinguishers at a location
 *      - Building/floor/zone mapping
 *   3. Queue - Inspection & Maintenance Schedule (FIFO)
 *      - Extinguishers due for inspection
 *      - Processed in order of scheduling
 *   4. Stack - Maintenance History / Recent Actions (LIFO)
 *      - Each inspection/maintenance recorded
 *      - Most recent action shown first
 *   5. Linked List - Per-Building Extinguisher Inventory
 *      - Dynamic list of extinguishers in a building
 *      - O(1) add, O(n) removal
 *
 * FUNCTIONALITIES:
 *   - Register new extinguisher (BST + Hash + LL)
 *   - Find extinguisher by serial (BST O(log n))
 *   - Find extinguishers by location (Hash O(1))
 *   - Schedule inspection (Queue)
 *   - Process inspection (Dequeue + Stack push)
 *   - View maintenance history (Stack LIFO)
 *   - Display all extinguishers sorted by serial (BST inorder)
 *   - Alert for overdue inspections
 *   - Remove decommissioned extinguisher
 * ============================================================================
 */
#include <iostream>
#include <string>
#include <unordered_map>
#include <queue>
#include <stack>
#include <iomanip>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <vector>
using namespace std;

// ============================================================================
// SECTION 1: ENTITY STRUCTS
// ============================================================================
struct Extinguisher {
    string serialNo;          // Unique serial number (e.g., "EXT-001")
    string type;              // "CO2", "Dry Powder", "Foam", "Water"
    string location;          // Building + floor + zone (e.g., "BldgA-Floor2-Lobby")
    string lastInspection;    // Date of last inspection
    string expiryDate;        // Expiry/refill date
    int capacity;             // Capacity in kg
    bool isActive;

    Extinguisher() : capacity(0), isActive(true) {}
    Extinguisher(string sn, string t, string loc, string li,
                 string exp, int cap)
        : serialNo(sn), type(t), location(loc), lastInspection(li),
          expiryDate(exp), capacity(cap), isActive(true) {}
};

struct MaintenanceRecord {
    string serialNo;
    string action;            // "INSPECTED", "REFILLED", "REPAIRED", "DECOMMISSIONED"
    string date;
    string notes;

    MaintenanceRecord() {}
    MaintenanceRecord(string sn, string a, string d, string n)
        : serialNo(sn), action(a), date(d), notes(n) {}
};

// ============================================================================
// SECTION 2: BST - EXTINGUISHERS BY SERIAL NUMBER
// ============================================================================
struct BSTNode {
    Extinguisher ext;
    BSTNode* left;
    BSTNode* right;

    BSTNode(Extinguisher e) : ext(e), left(nullptr), right(nullptr) {}
};

class ExtinguisherBST {
private:
    BSTNode* root;

    BSTNode* insert(BSTNode* node, Extinguisher e) {
        if (!node) return new BSTNode(e);
        if (e.serialNo < node->ext.serialNo)
            node->left = insert(node->left, e);
        else if (e.serialNo > node->ext.serialNo)
            node->right = insert(node->right, e);
        return node;
    }

    BSTNode* search(BSTNode* node, string serial) {
        if (!node || node->ext.serialNo == serial) return node;
        if (serial < node->ext.serialNo)
            return search(node->left, serial);
        return search(node->right, serial);
    }

    BSTNode* findMin(BSTNode* node) {
        while (node && node->left) node = node->left;
        return node;
    }

    BSTNode* remove(BSTNode* node, string serial) {
        if (!node) return nullptr;
        if (serial < node->ext.serialNo)
            node->left = remove(node->left, serial);
        else if (serial > node->ext.serialNo)
            node->right = remove(node->right, serial);
        else {
            if (!node->left) {
                BSTNode* temp = node->right;
                delete node;
                return temp;
            }
            if (!node->right) {
                BSTNode* temp = node->left;
                delete node;
                return temp;
            }
            BSTNode* temp = findMin(node->right);
            node->ext = temp->ext;
            node->right = remove(node->right, temp->ext.serialNo);
        }
        return node;
    }

    void inorder(BSTNode* node) {
        if (!node) return;
        inorder(node->left);
        cout << "    " << left << setw(10) << node->ext.serialNo
             << setw(16) << node->ext.type
             << setw(30) << node->ext.location
             << setw(6) << node->ext.capacity
             << setw(14) << node->ext.lastInspection
             << (node->ext.isActive ? "Active" : "Inactive") << "\n";
        inorder(node->right);
    }

    void collect(BSTNode* node, vector<Extinguisher>& vec) {
        if (!node) return;
        collect(node->left, vec);
        vec.push_back(node->ext);
        collect(node->right, vec);
    }

    void destroy(BSTNode* node) {
        if (!node) return;
        destroy(node->left);
        destroy(node->right);
        delete node;
    }

public:
    ExtinguisherBST() : root(nullptr) {}

    ~ExtinguisherBST() { destroy(root); }

    void insert(Extinguisher e) {
        root = insert(root, e);
    }

    Extinguisher* search(string serial) {
        BSTNode* node = search(root, serial);
        return node ? &node->ext : nullptr;
    }

    bool remove(string serial) {
        if (!search(serial)) return false;
        root = remove(root, serial);
        return true;
    }

    void display() {
        if (!root) {
            cout << "    [No extinguishers registered]\n";
            return;
        }
        cout << "    " << left << setw(10) << "Serial"
             << setw(16) << "Type"
             << setw(30) << "Location"
             << setw(6) << "Kg"
             << setw(14) << "Last Inspected"
             << "Status\n";
        cout << "    " << string(88, '-') << "\n";
        inorder(root);
    }

    vector<Extinguisher> getAll() {
        vector<Extinguisher> vec;
        collect(root, vec);
        return vec;
    }
};

// ============================================================================
// SECTION 3: LINKED LIST - BUILDING INVENTORY
// ============================================================================
struct InvNode {
    string serialNo;
    string type;
    string location;
    InvNode* next;

    InvNode(string sn, string t, string loc)
        : serialNo(sn), type(t), location(loc), next(nullptr) {}
};

class BuildingInventory {
private:
    InvNode* head;
    int count;

public:
    BuildingInventory() : head(nullptr), count(0) {}

    ~BuildingInventory() {
        InvNode* curr = head;
        while (curr) {
            InvNode* temp = curr;
            curr = curr->next;
            delete temp;
        }
    }

    void add(string serial, string type, string location) {
        InvNode* node = new InvNode(serial, type, location);
        node->next = head;
        head = node;
        count++;
    }

    bool remove(string serial) {
        InvNode* curr = head;
        InvNode* prev = nullptr;
        while (curr) {
            if (curr->serialNo == serial) {
                if (prev) prev->next = curr->next;
                else head = curr->next;
                delete curr;
                count--;
                return true;
            }
            prev = curr;
            curr = curr->next;
        }
        return false;
    }

    void display() {
        if (!head) {
            cout << "      [No extinguishers in this building]\n";
            return;
        }
        InvNode* curr = head;
        while (curr) {
            cout << "      " << curr->serialNo << " (" << curr->type
                 << ") @ " << curr->location << "\n";
            curr = curr->next;
        }
    }

    int getCount() { return count; }
};

// ============================================================================
// SECTION 4: MAIN FIRE EXTINGUISHER MANAGEMENT SYSTEM
// ============================================================================

string getCurrentDate() {
    time_t now = time(nullptr);
    tm* ltm = localtime(&now);
    stringstream ss;
    ss << (1900 + ltm->tm_year) << "-"
       << setw(2) << setfill('0') << (1 + ltm->tm_mon) << "-"
       << setw(2) << setfill('0') << ltm->tm_mday;
    return ss.str();
}

class FireExtinguisherSystem {
private:
    ExtinguisherBST extBST;                              // BST by serial
    unordered_map<string, BuildingInventory> buildings;  // Hash: building -> inventory
    queue<string> inspectionQueue;                       // Queue: FIFO inspections
    stack<MaintenanceRecord> maintHistory;               // Stack: recent actions
    int nextSerialNum;

    string nextSerial() {
        stringstream ss;
        ss << "EXT-" << setw(3) << setfill('0') << nextSerialNum++;
        return ss.str();
    }

    string extractBuilding(string location) {
        size_t pos = location.find('-');
        return (pos != string::npos) ? location.substr(0, pos) : location;
    }

public:
    FireExtinguisherSystem() : nextSerialNum(1) {
        seedData();
    }

    void seedData() {
        registerExtinguisher("CO2", "BldgA-Floor1-Reception", "2025-06-01", "2026-06-01", 5);
        registerExtinguisher("Dry Powder", "BldgA-Floor2-Hallway", "2025-05-15", "2026-05-15", 4);
        registerExtinguisher("Foam", "BldgA-Floor3-Lab", "2025-04-10", "2026-04-10", 6);
        registerExtinguisher("CO2", "BldgB-Floor1-ServerRoom", "2025-06-20", "2026-06-20", 2);
        registerExtinguisher("Water", "BldgB-Floor2-Office", "2025-03-05", "2026-03-05", 9);
        registerExtinguisher("Dry Powder", "BldgC-Floor1-Kitchen", "2025-07-01", "2026-07-01", 4);
        registerExtinguisher("Foam", "BldgC-Floor2-Workshop", "2025-02-15", "2026-02-15", 6);
    }

    // ====================================================================
    // REGISTER: BST insert + Hash table building inventory + Queue schedule
    // ====================================================================
    void registerExtinguisher(string type, string location,
                              string lastInsp, string expiry, int capacity) {
        // Validate inputs
        if (type.empty() || location.empty() || lastInsp.empty() || expiry.empty()) {
            cout << "  [ERROR] All fields are required.\n";
            return;
        }
        if (capacity <= 0) {
            cout << "  [ERROR] Capacity must be positive.\n";
            return;
        }

        string serial = nextSerial();
        Extinguisher ext(serial, type, location, lastInsp, expiry, capacity);
        extBST.insert(ext);                             // BST by serial

        string building = extractBuilding(location);
        buildings[building].add(serial, type, location); // Hash + Linked list

        inspectionQueue.push(serial);                    // Queue for inspection
        cout << "  [REGISTERED] " << serial << " (" << type << ", "
             << capacity << "kg) at " << location << "\n";
    }

    // ====================================================================
    // FIND BY SERIAL: BST O(log n)
    // ====================================================================
    void findBySerial(string serial) {
        Extinguisher* ext = extBST.search(serial);
        if (!ext) {
            cout << "  [ERROR] Extinguisher " << serial << " not found.\n";
            return;
        }
        cout << "  Serial: " << ext->serialNo << "\n";
        cout << "  Type: " << ext->type << "\n";
        cout << "  Location: " << ext->location << "\n";
        cout << "  Capacity: " << ext->capacity << " kg\n";
        cout << "  Last Inspection: " << ext->lastInspection << "\n";
        cout << "  Expiry: " << ext->expiryDate << "\n";
        cout << "  Status: " << (ext->isActive ? "Active" : "Inactive") << "\n";
    }

    // ====================================================================
    // FIND BY LOCATION: Hash table O(1) lookup
    // ====================================================================
    void findByLocation(string building) {
        auto it = buildings.find(building);
        if (it == buildings.end()) {
            cout << "  [INFO] No extinguishers found in " << building << ".\n";
            return;
        }
        cout << "  Extinguishers in " << building << " (Hash + Linked List):\n";
        it->second.display();
    }

    // ====================================================================
    // DISPLAY ALL: BST in-order (sorted by serial)
    // ====================================================================
    void displayAll() {
        extBST.display();
    }

    // ====================================================================
    // SCHEDULE INSPECTION: Queue (FIFO)
    // ====================================================================
    void scheduleInspection(string serial) {
        if (!extBST.search(serial)) {
            cout << "  [ERROR] Extinguisher " << serial << " not found.\n";
            return;
        }
        inspectionQueue.push(serial);
        cout << "  [SCHEDULED] " << serial << " added to inspection queue.\n";
    }

    // ====================================================================
    // PERFORM INSPECTION: Dequeue + Stack push
    // ====================================================================
    void performInspection() {
        if (inspectionQueue.empty()) {
            cout << "  [INFO] No inspections scheduled.\n";
            return;
        }

        string serial = inspectionQueue.front();
        inspectionQueue.pop();

        Extinguisher* ext = extBST.search(serial);
        if (!ext || !ext->isActive) {
            cout << "  [SKIP] " << serial << " is not active.\n";
            return;
        }

        string today = getCurrentDate();
        ext->lastInspection = today;

        MaintenanceRecord record(serial, "INSPECTED", today, "Routine inspection passed");
        maintHistory.push(record);

        cout << "  [INSPECTED] " << serial << " at " << ext->location
             << " on " << today << "\n";
    }

    // ====================================================================
    // MAINTENANCE HISTORY: Stack (most recent first)
    // ====================================================================
    void showHistory() {
        if (maintHistory.empty()) {
            cout << "  [INFO] No maintenance history.\n";
            return;
        }
        stack<MaintenanceRecord> temp = maintHistory;
        cout << "  Maintenance History (Stack - Most Recent First):\n";
        while (!temp.empty()) {
            MaintenanceRecord r = temp.top(); temp.pop();
            cout << "  " << r.serialNo << " | " << r.action
                 << " | " << r.date << " | " << r.notes << "\n";
        }
    }

    // ====================================================================
    // HISTORY FOR SPECIFIC EXTINGUISHER
    // ====================================================================
    void showHistoryFor(string serial) {
        if (!extBST.search(serial)) {
            cout << "  [ERROR] Extinguisher not found.\n";
            return;
        }
        stack<MaintenanceRecord> temp = maintHistory;
        bool found = false;
        while (!temp.empty()) {
            MaintenanceRecord r = temp.top(); temp.pop();
            if (r.serialNo == serial) {
                if (!found) {
                    cout << "  History for " << serial << ":\n";
                    found = true;
                }
                cout << "  " << r.action << " | " << r.date
                     << " | " << r.notes << "\n";
            }
        }
        if (!found)
            cout << "  [INFO] No history for " << serial << ".\n";
    }

    // ====================================================================
    // DECOMMISSION: Remove from all data structures
    // ====================================================================
    void decommission(string serial) {
        Extinguisher* ext = extBST.search(serial);
        if (!ext) {
            cout << "  [ERROR] Extinguisher not found.\n";
            return;
        }

        string building = extractBuilding(ext->location);
        ext->isActive = false;

        string today = getCurrentDate();
        MaintenanceRecord record(serial, "DECOMMISSIONED", today, "Removed from service");
        maintHistory.push(record);

        cout << "  [DECOMMISSIONED] " << serial << " at " << ext->location << "\n";
    }

    // ====================================================================
    // OVERDUE ALERT: Check expiry dates
    // ====================================================================
    void checkOverdue() {
        string today = getCurrentDate();
        vector<Extinguisher> all = extBST.getAll();
        bool found = false;

        cout << "  Overdue / Expiring Extinguishers:\n";
        cout << "  " << left << setw(10) << "Serial"
             << setw(15) << "Type"
             << setw(30) << "Location"
             << setw(16) << "Expiry"
             << "Status\n";
        cout << "  " << string(72, '-') << "\n";

        for (auto& e : all) {
            if (!e.isActive) continue;
            if (e.expiryDate < today) {
                cout << "  " << left << setw(10) << e.serialNo
                     << setw(15) << e.type
                     << setw(30) << e.location
                     << setw(16) << e.expiryDate
                     << "EXPIRED\n";
                found = true;
            }
        }
        if (!found)
            cout << "  [OK] No overdue extinguishers found.\n";
    }

    // ====================================================================
    // INSPECTION QUEUE STATUS
    // ====================================================================
    void showInspectionQueue() {
        if (inspectionQueue.empty()) {
            cout << "  [INFO] Inspection queue is empty.\n";
            return;
        }
        queue<string> temp = inspectionQueue;
        cout << "  Inspection Queue (FIFO):\n";
        int i = 1;
        while (!temp.empty()) {
            string serial = temp.front(); temp.pop();
            Extinguisher* ext = extBST.search(serial);
            string loc = ext ? ext->location : "Unknown";
            cout << "  " << i++ << ". " << serial << " @ " << loc << "\n";
        }
    }

    void run() {
        cout << "\n=============================================\n";
        cout << "   FIRE EXTINGUISHER MANAGEMENT SYSTEM\n";
        cout << "   Data Structures: BST (Serial Sort),\n";
        cout << "   Hash Table (Location), Queue (Inspection),\n";
        cout << "   Stack (History), Linked List (Building Inv)\n";
        cout << "=============================================\n\n";

        int choice, capacity;
        string serial, type, location, lastInsp, expiry, building;

        do {
            cout << "\n------ MENU ------\n";
            cout << "  [BST - Serial Number Index]\n";
            cout << "    1. Display All (Sorted by Serial)\n";
            cout << "    2. Search by Serial (BST O(log n))\n";
            cout << "  [HASH TABLE - Location]\n";
            cout << "    3. Find by Building (Hash O(1))\n";
            cout << "  [LINKED LIST - Building Inventory]\n";
            cout << "    (View via option 3)\n";
            cout << "  [QUEUE - Inspection Schedule]\n";
            cout << "    4. Schedule Inspection (Enqueue)\n";
            cout << "    5. Show Inspection Queue\n";
            cout << "    6. Perform Inspection (Dequeue + Stack)\n";
            cout << "  [STACK - Maintenance History]\n";
            cout << "    7. All Maintenance History\n";
            cout << "    8. History for Specific Extinguisher\n";
            cout << "  [MANAGEMENT]\n";
            cout << "    9. Register New Extinguisher (BST+Hash+LL)\n";
            cout << "   10. Decommission Extinguisher\n";
            cout << "   11. Check Overdue Expiry\n";
            cout << "    0. Exit\n";
            cout << "Choice: ";
            cin >> choice;
            if (cin.fail()) {
                cout << "  [ERROR] Invalid input. Please enter a number.\n";
                cin.clear();
                cin.ignore(10000, '\n');
                choice = -1;
            } else {
                cin.ignore();
            }

            switch (choice) {
                case 1: displayAll(); break;
                case 2:
                    cout << "  Serial Number: "; getline(cin, serial);
                    if (serial.empty()) { cout << "  [ERROR] Input cannot be empty.\n"; break; }
                    findBySerial(serial);
                    break;
                case 3:
                    cout << "  Building Name (e.g., BldgA, BldgB): "; getline(cin, building);
                    if (building.empty()) { cout << "  [ERROR] Input cannot be empty.\n"; break; }
                    findByLocation(building);
                    break;
                case 4:
                    cout << "  Serial Number: "; getline(cin, serial);
                    if (serial.empty()) { cout << "  [ERROR] Input cannot be empty.\n"; break; }
                    scheduleInspection(serial);
                    break;
                case 5: showInspectionQueue(); break;
                case 6: performInspection(); break;
                case 7: showHistory(); break;
                case 8:
                    cout << "  Serial Number: "; getline(cin, serial);
                    if (serial.empty()) { cout << "  [ERROR] Input cannot be empty.\n"; break; }
                    showHistoryFor(serial);
                    break;
                case 9:
                    cout << "  Type (CO2/Dry Powder/Foam/Water): "; getline(cin, type);
                    if (type != "CO2" && type != "Dry Powder" && type != "Foam" && type != "Water") {
                        cout << "  [ERROR] Invalid type. Use: CO2, Dry Powder, Foam, or Water.\n";
                        break;
                    }
                    cout << "  Location (e.g., BldgA-Floor1-Reception): "; getline(cin, location);
                    if (location.find('-') == string::npos) {
                        cout << "  [ERROR] Use format: Building-Floor-Room (e.g., BldgA-Floor1-Hallway).\n";
                        break;
                    }
                    cout << "  Last Inspection Date (YYYY-MM-DD): "; getline(cin, lastInsp);
                    cout << "  Expiry Date (YYYY-MM-DD): "; getline(cin, expiry);
                    cout << "  Capacity (kg): "; cin >> capacity; cin.ignore();
                    if (cin.fail()) {
                        cout << "  [ERROR] Invalid capacity.\n";
                        cin.clear();
                        cin.ignore(10000, '\n');
                        break;
                    }
                    registerExtinguisher(type, location, lastInsp, expiry, capacity);
                    break;
                case 10:
                    cout << "  Serial Number: "; getline(cin, serial);
                    if (serial.empty()) { cout << "  [ERROR] Input cannot be empty.\n"; break; }
                    decommission(serial);
                    break;
                case 11: checkOverdue(); break;
                case 0: cout << "  Stay safe! Goodbye.\n"; break;
                default: cout << "  [ERROR] Invalid choice.\n";
            }
        } while (choice != 0);
    }
};

int main() {
    FireExtinguisherSystem system;
    system.run();
    return 0;
}
